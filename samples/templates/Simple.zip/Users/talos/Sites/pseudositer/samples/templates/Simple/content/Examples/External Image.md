The image below lives in the *assets/* directory.

![Garth's mom](assets/example.jpg)

Unlike images placed directly in *content/*, you can add text around it.